from PyQt6.QtWidgets import (QWidget, QDialog, QTableWidget, QTableWidgetItem, QVBoxLayout, QPushButton, QLabel,
                             QLineEdit, QComboBox, QMessageBox)
from PyQt6.QtGui import QIcon
import sqlite3
import re
from datetime import datetime


class StyledWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet("""
            background-color: #f5f5f5;
            font-family: Arial, sans-serif;
        """)


class WindowForPostav(StyledWidget):
    def __init__(self):
        super().__init__()
        new_window = QDialog(self)
        new_window.setWindowTitle('Список поставок')
        new_window.setGeometry(370, 200, 400, 300)
        new_window.setWindowIcon(QIcon('icon2.png'))

        layout = QVBoxLayout()
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(['Id', 'Дата поставки', '№ поставщика'])

        # Подключение к базе данных
        self.connection = sqlite3.connect('data.db')
        self.cursor = self.connection.cursor()

        # Получение и отображение данных в таблице
        self.fetch_data()

        layout.addWidget(self.table)

        # Создание кнопки
        add_button = QPushButton('Добавить информацию')
        add_button.clicked.connect(self.add_info)
        add_button.clicked.connect(new_window.accept)  # Добавляем закрытие окна при нажатии кнопки
        add_button.setStyleSheet("""
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
        """)
        layout.addWidget(add_button)

        # Окно для пользователя
        new_window.setLayout(layout)
        new_window.exec()

    def fetch_data(self):
        # Получение данных из таблицы 'postav'
        self.cursor.execute("SELECT * FROM postav")
        data = self.cursor.fetchall()

        # Очистка таблицы перед обновлением
        self.table.setRowCount(0)

        # Отображение данных в таблице
        for row_num, row_data in enumerate(data):
            self.table.insertRow(row_num)
            for col_num, col_data in enumerate(row_data):
                self.table.setItem(row_num, col_num, QTableWidgetItem(str(col_data)))

    def add_info(self):
        # Диалоговое окно для ввода информации
        dialog = QDialog()
        dialog.setWindowTitle('Добавление информации о поставке')
        dialog.setGeometry(400, 250, 300, 200)
        dialog.setWindowIcon(QIcon('icon2.png'))
        dialog.setFixedWidth(300)
        dialog.setFixedHeight(200)
        layout = QVBoxLayout()

        # Создание полей для ввода информации
        label1 = QLabel('Дата:')
        self.date_input = QLineEdit()
        self.date_input.setPlaceholderText('гггг.мм.дд')
        self.date_input.setStyleSheet("""
                                        padding: 8px;
                                        border: 2px solid #3498db;
                                        border-radius: 5px;
                                        background-color: #ecf0f1;
                                """)
        layout.addWidget(label1)
        layout.addWidget(self.date_input)

        def validate_date():
            date = self.date_input.text()
            regex = r'^\d{4}\.\d{2}\.\d{2}$'
            if not re.match(regex, date):
                self.date_input.setStyleSheet("""padding: 8px;
                                        border: 2px solid red;
                                        border-radius: 5px;
                                        background-color: #ecf0f1;
                                        """)
                QMessageBox.warning(self, 'Ошибка', 'Неправильный формат даты')
            else:
                try:
                    datetime.strptime(date, '%Y.%m.%d')
                    self.date_input.setStyleSheet("border: 1px solid black;")
                except ValueError:
                    self.date_input.setStyleSheet("border: 1px solid red;")
                    QMessageBox.warning(self, 'Ошибка', 'Несуществующая дата')

        self.date_input.editingFinished.connect(validate_date)

        label2 = QLabel('№ поставщика:')
        self.user_input = QComboBox()
        self.user_input.setStyleSheet("""
                                                padding: 8px;
                                                border: 2px solid #3498db;
                                                border-radius: 5px;
                                                background-color: #ecf0f1;
                                                """)
        self.user_input.addItems(self.get_users())
        layout.addWidget(label2)
        layout.addWidget(self.user_input)

        # Кнопка добавления информации в базу данных
        add_button = QPushButton('Добавить')
        add_button.clicked.connect(self.insert_data)
        add_button.setStyleSheet("""
                                    background-color: #3498db;
                                    color: white;
                                    padding: 10px 15px;
                                    border: none;
                                    border-radius: 5px;
                                    text-align: center;
                                    text-decoration: none;
                                    display: inline-block;
                                    font-size: 14px;
                                    margin: 4px 2px;
                                    cursor: pointer;
                                """)
        add_button.clicked.connect(dialog.accept)  # Добавляем закрытие окна при нажатии кнопки
        layout.addWidget(add_button)

        dialog.setLayout(layout)
        dialog.exec()

    def get_users(self):
        # Получение пользователей из базы данных
        self.cursor.execute("SELECT FIO FROM users")
        users = self.cursor.fetchall()
        users_list = [str(user[0]) for user in users]
        return users_list

    def insert_data(self):
        # Получение введенных данных
        date = self.date_input.text()
        user = self.user_input.currentText()

        if not date:
            QMessageBox.critical(self, 'Ошибка', 'Пожалуйста, заполните все поля.')
            return

        # Добавление данных в таблицу 'product'
        self.cursor.execute("INSERT INTO postav (date_postav, Id_user) VALUES (?, ?)", (date, user))
        self.connection.commit()

        # Обновление таблицы
        self.fetch_data()
