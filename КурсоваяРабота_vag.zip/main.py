import sys
from PyQt6.QtGui import QIcon
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox, QComboBox
import sqlite3
from user_window import WindowForUser
from admin_window import WindowForAdmin


class StyledWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet("""
            background-color: #f5f5f5;
            font-family: Arial, sans-serif;
        """)

class AuthorizationApp(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle('Авторизация')
        self.setGeometry(490, 230, 300, 200)
        self.setWindowIcon(QIcon('icon2.png'))

        layout = QVBoxLayout()

        role_label = QLabel('Роль:')
        self.role_combobox = QComboBox()
        self.role_combobox.addItem('Пользователь')
        self.role_combobox.addItem('Администратор')
        layout.addWidget(role_label)
        layout.addWidget(self.role_combobox)

        login_label = QLabel('Логин:')
        self.login_input = QLineEdit()
        self.login_input.setPlaceholderText('Введите логин..')
        layout.addWidget(login_label)
        layout.addWidget(self.login_input)

        password_label = QLabel('Пароль:')
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText('Введите пароль..')
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(password_label)
        layout.addWidget(self.password_input)

        self.login_button = QPushButton('Войти')
        self.login_button.clicked.connect(self.authorize)
        layout.addWidget(self.login_button)

        self.setLayout(layout)

        # Применение стилей
        self.setStyleSheet("""
            QWidget {
                background-color: #f5f5f5;
                font-family: Arial, sans-serif;
            }

            QLabel {
                color: #333;
            }

            QLineEdit {
                padding: 8px;
                border: 2px solid #3498db;
                border-radius: 5px;
                background-color: #ecf0f1;
            }

            QPushButton {
                background-color: #3498db;
                color: white;
                padding: 10px 15px;
                border: none;
                border-radius: 5px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 14px;
                margin: 4px 2px;
                cursor: pointer;
            }

            QPushButton:hover {
                background-color: #2980b9;
            }

            QComboBox {
                padding: 8px;
                border: 2px solid #3498db;
                border-radius: 5px;
                background-color: #ecf0f1;
            }
        """)

    def showEvent(self, event):
        super().showEvent(event)
        self.login_input.setFocus()

    def authorize(self):
        login = self.login_input.text()
        password = self.password_input.text()
        role = self.role_combobox.currentText()

        # Соединение с базой данных
        conn = sqlite3.connect('data.db')
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE login=? AND password=? AND role=?', (login, password, role))
        user = cursor.fetchone()

        if user:
            if role == 'Пользователь':
                self.open_window1()
            elif role == 'Администратор':
                self.open_window2()
        else:
            QMessageBox.warning(self, 'Ошибка', 'Неверный логин или пароль')
        conn.close()

    def open_window1(self):
        window = WindowForUser()
        window.show()

    def open_window2(self):
        window = WindowForAdmin()
        window.show()


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = AuthorizationApp()
    window.show()
    sys.exit(app.exec())
