from PyQt6.QtWidgets import (QWidget, QDialog, QVBoxLayout, QPushButton, QLabel, QMessageBox, QComboBox, QGridLayout,
                             QHBoxLayout)
from PyQt6.QtCore import Qt
from docx.shared import Inches
from tovar import WindowForTovar
from postav import WindowForPostav
from looking import Look
from personal import PersonalData
import sqlite3
from docx import Document
from PyQt6.QtGui import QIcon, QFont, QPixmap
from num2words import num2words


class StyledWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet("""
            background-color: #f5f5f5;
            font-family: Arial, sans-serif;
        """)


class WindowForUser(StyledWidget):
    def __init__(self):
        super().__init__()
        new_window = QDialog(self)
        new_window.setWindowTitle('Окно для пользователя')
        new_window.setGeometry(379, 200, 500, 400)
        new_window.setFixedWidth(500)
        new_window.setFixedHeight(400)
        new_window.setWindowIcon(QIcon('icon2.png'))

        layout = QVBoxLayout()

        button_layout = QHBoxLayout()
        add_button = QPushButton('Личный кабинет')
        add_button.clicked.connect(self.personal)
        add_button.setStyleSheet("""
                            background-color: #3500db;
                            color: white;
                            padding: 15px 15px;
                            border: none;
                            border-radius: 5px;
                            text-align: center;
                            text-decoration: none;
                            display: inline-block;
                            font-size: 14px;
                            margin: 4px 2px;
                            cursor: pointer;
                        """)
        add_button.setIcon(QIcon('icon1.png'))
        button_layout.addWidget(add_button)

        add_button = QPushButton('Инструкция')
        add_button.clicked.connect(self.instruction)
        add_button.setStyleSheet("""
                    background-color: #3500db;
                    color: white;
                    padding: 15px 15px;
                    border: none;
                    border-radius: 5px;
                    text-align: center;
                    text-decoration: none;
                    display: inline-block;
                    font-size: 14px;
                    margin: 4px 2px;
                    cursor: pointer;
                """)
        add_button.setIcon(QIcon('icon3.png'))
        button_layout.addWidget(add_button)

        layout.addLayout(button_layout)

        h_layout = QHBoxLayout()

        image_label = QLabel()
        pixmap = QPixmap('icon2.png')
        pixmap = pixmap.scaled(100, 100)
        image_label.setPixmap(pixmap)
        image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        h_layout.addWidget(image_label)

        enter_label = QLabel('Перед началом работы ознакомьтесь с инструкцией.\n'
                             'Затем приступайте к работе. Хорошего дня и лёгкой работы!')
        enter_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        enter_label.setFont(QFont("Arial", 10))  # изменение шрифта и размера
        # enter_label.setStyleSheet("color: gray")
        h_layout.addWidget(enter_label)

        layout.addLayout(h_layout)

        add_button = QPushButton('Просмотр')
        add_button.clicked.connect(self.look)
        add_button.setStyleSheet("""
                    background-color: #3498db;
                    color: white;
                    padding: 10px 15px;
                    border: none;
                    border-radius: 5px;
                    text-align: center;
                    text-decoration: none;
                    display: inline-block;
                    font-size: 14px;
                    margin: 4px 2px;
                    cursor: pointer;
                """)
        layout.addWidget(add_button)

        add_button = QPushButton('Внести информацию о НОВОЙ ПОСТАВКЕ')
        add_button.clicked.connect(self.open_postav)
        add_button.setStyleSheet("""
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
        """)
        layout.addWidget(add_button)

        add_button = QPushButton('Внести информацию о НОВОМ ТОВАРЕ')
        add_button.clicked.connect(self.open_tovar)
        add_button.setStyleSheet("""
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
        """)
        layout.addWidget(add_button)

        report_button = QPushButton('Отчет о поставке')
        report_button.clicked.connect(self.otchet)
        report_button.setStyleSheet("""
                    background-color: #3498db;
                    color: white;
                    padding: 10px 15px;
                    border: none;
                    border-radius: 5px;
                    text-align: center;
                    text-decoration: none;
                    display: inline-block;
                    font-size: 14px;
                    margin: 4px 2px;
                    cursor: pointer;
                """)
        layout.addWidget(report_button)

        new_window.setLayout(layout)
        # Окно для пользователя
        new_window.exec()

    def instruction(self):
        self.close()
        QMessageBox.information(self, "Инструкция", "Перед использованием ознакомьтесь с инструкцией:\n\n\n"
                                                    "1. Первым делом, нажмите на кнопку \"Внести информацию о НОВОЙ ПОСТАВКЕ\", после чего укажите необходимые данные; *\n\n"
                                                    "2. Затем нажмите на кнопку \"Внести информацию о НОВОМ ТОВАРЕ\", после чего укажите необходимые данные, выбрав Id Вашей поставки, "
                                                    "которую Вы только что добавили; **\n"
                                                    "\n3. Если Вам необходимо составить отчёт - нажмите на соответствующую кнопку. Выберите номер поставки, которая Вас интересует. Готовый отчёт поместите в нужную Вам папку.\n\n"
                                                    "Чтобы изменить информацию о себе перейдите в \"Личный кабинет\" => введите свои логин и пароль, затем внесите Фамилию, Имя и Отчество, а также дату рождения. *\n\n"
                                                    "(Если Вам требуется провести анализ данных, Вы также можете воспользоваться функцией \"Просмотр\")\n\n\n\n\n* Вводите дату в формате ГГГГ.ММ.ДД;\n** Cвой номер - Id, Вы можете увидеть, нажав на кнопку \"Просмотр\" => \"Узнать информацию о поставках\"")

    def personal(self):
        self.close()
        window = PersonalData()
        window.show()

    def open_tovar(self):
        self.close()
        window = WindowForTovar()
        window.show()

    def open_postav(self):
        self.close()
        window = WindowForPostav()
        window.show()

    def look(self):
        self.close()
        window = Look()
        window.show()

    def otchet(self):
        self.close()
        window = Otchet()
        window.show()


class Otchet(StyledWidget):
    def __init__(self):
        super().__init__()
        new_window = QDialog(self)
        new_window.setWindowTitle('Отчёт о поставке')
        new_window.setGeometry(500, 300, 200, 100)
        new_window.setFixedWidth(250)
        new_window.setFixedHeight(160)
        new_window.setWindowIcon(QIcon('icon2.png'))
        layout = QGridLayout()
        label = QLabel('Выберите № поставки, для\nкоторой Вы хотите сделать отчёт:')
        label.setFont(QFont("Arial", 10))
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.ot_postav = QComboBox()
        self.ot_postav.setStyleSheet("""
                                        padding: 8px;
                                        border: 2px solid #3498db;
                                        border-radius: 5px;
                                        background-color: #ecf0f1;
                                        """)
        self.ot_postav.addItems(self.otchet_postav())

        add_button = QPushButton('Составить отчёт')
        add_button.setStyleSheet("""
                        background-color: #3498db;
                        color: white;
                        padding: 10px 15px;
                        border: none;
                        border-radius: 5px;
                        text-align: center;
                        text-decoration: none;
                        display: inline-block;
                        font-size: 14px;
                        margin: 4px 2px;
                        cursor: pointer;
                    """)
        add_button.clicked.connect(self.generate_report)

        layout.addWidget(label, 0, 0, 1, 2)
        layout.addWidget(self.ot_postav, 1, 0, 1, 2)
        layout.addWidget(add_button, 2, 0, 1, 2)
        new_window.setLayout(layout)
        new_window.exec()

    def otchet_postav(self):
        # Подключение к базе данных
        self.connection = sqlite3.connect('data.db')
        self.cursor = self.connection.cursor()
        # Получение пользователей из базы данных
        self.cursor.execute("SELECT Id FROM postav")
        postavs = self.cursor.fetchall()
        users_list = [str(postav[0]) for postav in postavs]
        return users_list

    def generate_report(self):
        selected_postav = self.ot_postav.currentText()  # Получаем выбранный номер поставки
        document = Document()
        document.add_heading('Отчёт о Вашей поставке:', 0)
        document.add_heading(f'Поставка № {selected_postav}.', level=1)  # Добавление номера поставки в название

        table = document.add_table(rows=1, cols=4)
        table.autofit = False
        table.columns[0].width = Inches(2)
        table.columns[1].width = Inches(1)
        table.columns[2].width = Inches(1)
        table.columns[3].width = Inches(1)
        table.style = 'Table Grid'

        hdr_cells = table.rows[0].cells
        hdr_cells[0].text = 'НАЗВАНИЕ'
        hdr_cells[1].text = 'ВЕС (1КГ / 1Л)'
        hdr_cells[2].text = 'ЦЕНА (ЗА 1КГ / 1Л)'
        hdr_cells[3].text = 'СУММА'

        # Получение информации о товарах и дате поставки из базы данных и добавление их в отчёт
        self.cursor.execute("SELECT Name, Weight, Price FROM product WHERE Id_postav=?", (selected_postav,))
        products = self.cursor.fetchall()
        total_sum = 0  # Переменная для хранения суммы всех товаров в поставке
        for product in products:
            name = product[0]
            weight = product[1]
            price = product[2]
            row_cells = table.add_row().cells
            row_cells[0].text = name
            row_cells[1].text = str(weight)
            row_cells[2].text = str(price)
            row_cells[3].text = str(weight * price)
            total_sum += weight * price  # Вычисление суммы каждого товара и добавление в общую сумму

        self.cursor.execute("SELECT date_postav FROM postav WHERE Id=?", (selected_postav,))
        date_postav = self.cursor.fetchone()
        if date_postav:
            document.add_paragraph(f"\nДата поставки: {date_postav[0]}\nИтого: {str(total_sum)}  "
                                   f"({num2words(total_sum, lang='ru')}) p.")
            # document.add_paragraph(f"Итого: {str(total_sum)} рублей")  # Добавление суммы всей поставки в документ
        else:
            document.add_paragraph("Дата поставки не найдена")

        self.connection.close()

        document.save('отчет.docx')
        QMessageBox.about(self, "Отчёт", "Отчёт успешно сохранен в файле отчет.docx")
