from PyQt6.QtWidgets import (QWidget, QDialog, QTableWidget, QTableWidgetItem, QVBoxLayout, QPushButton, QLabel,
                             QLineEdit, QMessageBox)
from PyQt6.QtGui import QIcon
import sqlite3


class StyledWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet("""
            background-color: #f5f5f5;
            font-family: Arial, sans-serif;
        """)


class WindowForAdmin(StyledWidget):
    def __init__(self):
        super().__init__()
        new_window = QDialog(self)
        new_window.setWindowTitle('Окно для администратора')
        new_window.setGeometry(370, 200, 600, 400)
        new_window.setWindowIcon(QIcon('icon2.png'))

        layout = QVBoxLayout()

        self.login_label = QLabel('Добавьте Логин нового пользователя:')
        self.login_input = QLineEdit()
        self.login_input.setPlaceholderText('Введите логин..')
        layout.addWidget(self.login_label)
        layout.addWidget(self.login_input)

        self.password_label = QLabel('Добавьте Пароль нового пользователя:')
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText('Введите пароль..')
        layout.addWidget(self.password_label)
        layout.addWidget(self.password_input)

        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(['Id', 'LogIn', 'Password', 'Role'])

        # заполнение / обновление таблицы
        self.populate_table()

        layout.addWidget(self.table)

        add_button = QPushButton('Добавить запись')
        add_button.clicked.connect(self.add_record)
        add_button.setStyleSheet("""
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
        """)
        layout.addWidget(add_button)

        del_button = QPushButton('Удалить запись')
        del_button.clicked.connect(self.del_record)
        del_button.setStyleSheet("""
                    background-color: #3498db;
                    color: white;
                    padding: 10px 15px;
                    border: none;
                    border-radius: 5px;
                    text-align: center;
                    text-decoration: none;
                    display: inline-block;
                    font-size: 14px;
                    margin: 4px 2px;
                    cursor: pointer;
                """)
        layout.addWidget(del_button)

        new_window.setLayout(layout)
        new_window.exec()

    def populate_table(self):
        # Подключение к базе данных
        connection = sqlite3.connect('data.db')
        cursor = connection.cursor()

        cursor.execute("SELECT * FROM users")
        data = cursor.fetchall()

        for row_num, row_data in enumerate(data):
            self.table.insertRow(row_num)
            for col_num, col_data in enumerate(row_data):
                self.table.setItem(row_num, col_num, QTableWidgetItem(str(col_data)))
        connection.close()

    def add_record(self):
        login = self.login_input.text()
        password = self.password_input.text()

        # Проверка заполненности логина и пароля
        if not login:
            QMessageBox.critical(self, 'Ошибка', 'Логин не заполнен. Пожалуйста, заполните все поля.')
            return
        if not password:
            QMessageBox.critical(self, 'Ошибка', 'Пароль не заполнен. Пожалуйста, заполните все поля.')
            return

        # Подключение к базе данных
        connection = sqlite3.connect('data.db')
        cursor = connection.cursor()

        # Проверка наличия такого логина в базе данных
        cursor.execute(f"SELECT * FROM users WHERE login = '{login}'")
        existing_user = cursor.fetchone()
        if existing_user:
            QMessageBox.critical(self, 'Ошибка', 'Такой логин уже существует.')
            connection.close()
            return
        # Добавление записи в таблицу 'users'
        cursor.execute(f"INSERT INTO users (login, password) VALUES ('{login}', '{password}')")
        # Созранение изменений
        connection.commit()
        # Опустошение таблицы
        self.table.setRowCount(0)
        # Обновление информации
        self.populate_table()
        connection.close()

    def del_record(self):
        # Получите индекс выбранной строки
        selected_row = self.table.currentRow()

        # Проверьте, что строка была выбрана
        if selected_row >= 0:
            # Получите значение первого столбца (Id) выбранной строки
            record_id = self.table.item(selected_row, 0).text()

            # Подключитесь к базе данных
            connection = sqlite3.connect('data.db')
            cursor = connection.cursor()

            # Удалите запись с помощью значения Id
            cursor.execute(f"DELETE FROM users WHERE Id = {record_id}")
            # Сохранение изменения
            connection.commit()
            # Очищение таблицы
            self.table.clearContents()
            # Обновление информацию в таблице
            self.populate_table()
            # Закрывается соединение с базой данных
            connection.close()
        else:
            QMessageBox.critical(self, 'Ошибка', 'Выберите запись для удаления.')
