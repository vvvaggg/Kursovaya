from PyQt6.QtWidgets import QWidget, QDialog, QVBoxLayout, QPushButton, QTableWidget, QTableWidgetItem
from PyQt6.QtGui import QIcon
import sqlite3


class StyledWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet("""
            background-color: #f5f5f5;
            font-family: Arial, sans-serif;
        """)


class Look(StyledWidget):
    def __init__(self):
        super().__init__()
        new_window = QDialog(self)
        new_window.setWindowTitle('Просмотр')
        new_window.setGeometry(500, 300, 200, 100)
        new_window.setWindowIcon(QIcon('icon2.png'))
        layout = QVBoxLayout()

        # Создание кнопки
        add_button = QPushButton('Узнать информацию о Поставках')
        add_button.clicked.connect(self.looking_postav)
        add_button.setStyleSheet("""
            background-color: #3500db;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
        """)
        layout.addWidget(add_button)

        add_button = QPushButton('Узнать информацию о Товарах')
        add_button.clicked.connect(self.looking_product)
        add_button.setStyleSheet("""
                    background-color: #3500db;
                    color: white;
                    padding: 10px 15px;
                    border: none;
                    border-radius: 5px;
                    text-align: center;
                    text-decoration: none;
                    display: inline-block;
                    font-size: 14px;
                    margin: 4px 2px;
                    cursor: pointer;
                """)
        layout.addWidget(add_button)

        new_window.setLayout(layout)
        new_window.exec()

    def looking_postav(self):
        self.close()
        window = LookingPostav()
        window.show()

    def looking_product(self):
        self.close()
        window = LookingProduct()
        window.show()


class LookingPostav(StyledWidget):
    def __init__(self):
        super().__init__()
        new_window = QDialog(self)
        new_window.setWindowTitle('Список поставок')
        new_window.setGeometry(450, 200, 370, 300)
        new_window.setWindowIcon(QIcon('icon2.png'))

        layout = QVBoxLayout()
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(['Id', 'Дата поставки', '№ поставщика'])

        # Подключение к базе данных
        self.connection = sqlite3.connect('data.db')
        self.cursor = self.connection.cursor()

        # Получение и отображение данных в таблице
        self.fetch_data()

        layout.addWidget(self.table)

        new_window.setLayout(layout)
        new_window.exec()

    def fetch_data(self):
        # Получение данных из таблицы 'postav'
        self.cursor.execute("SELECT * FROM postav")
        data = self.cursor.fetchall()

        # Очистка таблицы перед обновлением
        self.table.setRowCount(0)

        # Отображение данных в таблице
        for row_num, row_data in enumerate(data):
            self.table.insertRow(row_num)
            for col_num, col_data in enumerate(row_data):
                self.table.setItem(row_num, col_num, QTableWidgetItem(str(col_data)))


class LookingProduct(StyledWidget):
    def __init__(self):
        super().__init__()
        new_window = QDialog(self)
        new_window.setWindowTitle('Список товаров')
        new_window.setGeometry(360, 200, 565, 350)
        new_window.setFixedWidth(565)
        new_window.setWindowIcon(QIcon('icon2.png'))

        layout = QVBoxLayout()
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(['Id', 'Название', 'КГ / Л', 'Цена за 1 шт.', '№ поставки'])

        # Подключение к базе данных
        self.connection = sqlite3.connect('data.db')
        self.cursor = self.connection.cursor()

        # Получение и отображение данных в таблице
        self.fetch_data()

        layout.addWidget(self.table)

        new_window.setLayout(layout)
        new_window.exec()

    def fetch_data(self):
        # Получение данных из таблицы 'postav'
        self.cursor.execute("SELECT * FROM product")
        data = self.cursor.fetchall()

        # Очистка таблицы перед обновлением
        self.table.setRowCount(0)

        # Отображение данных в таблице
        for row_num, row_data in enumerate(data):
            self.table.insertRow(row_num)
            for col_num, col_data in enumerate(row_data):
                self.table.setItem(row_num, col_num, QTableWidgetItem(str(col_data)))
