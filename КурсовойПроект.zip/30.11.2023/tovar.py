from PyQt6.QtWidgets import (QWidget, QDialog, QTableWidget, QTableWidgetItem, QVBoxLayout, QPushButton, QLabel,
                             QLineEdit, QComboBox, QMessageBox)
from PyQt6.QtGui import QIcon, QIntValidator
import sqlite3


class StyledWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet("""
            background-color: #f5f5f5;
            font-family: Arial, sans-serif;
        """)


class WindowForTovar(StyledWidget):
    def __init__(self):
        super().__init__()
        new_window = QDialog(self)
        new_window.setWindowTitle('Список товаров')
        new_window.setGeometry(370, 200, 600, 300)
        new_window.setWindowIcon(QIcon('icon2.png'))

        layout = QVBoxLayout()
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(['Id', 'Название', 'КГ / Л', 'Цена за 1КГ / 1Л', '№ поставки'])

        # Подключение к базе данных
        self.connection = sqlite3.connect('data.db')
        self.cursor = self.connection.cursor()

        # Получение и отображение данных в таблице
        self.fetch_data()

        layout.addWidget(self.table)

        # Создание кнопки
        add_button = QPushButton('Добавить информацию')
        add_button.clicked.connect(self.add_info)
        add_button.setStyleSheet("""
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
        """)
        layout.addWidget(add_button)

        # Окно для пользователя
        new_window.setLayout(layout)
        new_window.exec()

    def fetch_data(self):
        # Получение данных из таблицы 'product'
        self.cursor.execute("SELECT * FROM product")
        data = self.cursor.fetchall()

        # Очистка таблицы перед обновлением
        self.table.setRowCount(0)

        # Отображение данных в таблице
        for row_num, row_data in enumerate(data):
            self.table.insertRow(row_num)
            for col_num, col_data in enumerate(row_data):
                self.table.setItem(row_num, col_num, QTableWidgetItem(str(col_data)))

    def add_info(self):
        # Диалоговое окно для ввода информации
        dialog = QDialog()
        dialog.setWindowTitle('Добавление информации о товаре')
        dialog.setGeometry(480, 250, 280, 330)
        dialog.setWindowIcon(QIcon('icon2.png'))
        dialog.setFixedWidth(280)
        dialog.setFixedHeight(330)
        layout = QVBoxLayout()

        # Создание полей для ввода информации
        label1 = QLabel('Название:')
        self.name_input = QLineEdit()
        self.name_input.setStyleSheet("""
                                                padding: 8px;
                                                border: 2px solid #3498db;
                                                border-radius: 5px;
                                                background-color: #ecf0f1;
                                        """)
        layout.addWidget(label1)
        layout.addWidget(self.name_input)

        label2 = QLabel('Вес или объём:')
        self.weight_input = QLineEdit()
        self.weight_input.setPlaceholderText('КГ / Л')
        self.weight_input.setStyleSheet("""
                                                padding: 8px;
                                                border: 2px solid #3498db;
                                                border-radius: 5px;
                                                background-color: #ecf0f1;
                                        """)
        layout.addWidget(label2)
        layout.addWidget(self.weight_input)

        validator = QIntValidator()
        self.weight_input.setValidator(validator)

        label3 = QLabel('Цена за 1 шт.:')
        self.price_input = QLineEdit()
        self.price_input.setPlaceholderText('Цена в рублях')
        self.price_input.setStyleSheet("""
                                                padding: 8px;
                                                border: 2px solid #3498db;
                                                border-radius: 5px;
                                                background-color: #ecf0f1;
                                        """)
        layout.addWidget(label3)
        layout.addWidget(self.price_input)

        validator = QIntValidator()
        self.price_input.setValidator(validator)

        label4 = QLabel('Выберите № поставки:')
        self.postav_input = QComboBox()
        self.postav_input.setStyleSheet("""
                                                        padding: 8px;
                                                        border: 2px solid #3498db;
                                                        border-radius: 5px;
                                                        background-color: #ecf0f1;
                                                        """)
        self.postav_input.addItems(self.get_postavs())
        layout.addWidget(label4)
        layout.addWidget(self.postav_input)

        # Кнопка добавления информации в базу данных
        add_button = QPushButton('Добавить')
        add_button.clicked.connect(self.insert_data)
        add_button.clicked.connect(dialog.accept)  # Добавляем закрытие окна при нажатии кнопки
        add_button.setStyleSheet("""
            background-color: #3498db;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin: 4px 2px;
            cursor: pointer;
        """)
        layout.addWidget(add_button)

        dialog.setLayout(layout)
        dialog.exec()

    def get_postavs(self):
        # Получение пользователей из базы данных
        self.cursor.execute("SELECT Id FROM postav")
        postavs = self.cursor.fetchall()
        postavs_list = [str(postav[0]) for postav in postavs]
        return postavs_list

    def insert_data(self):
        # Получение введенных данных
        name = self.name_input.text()
        weight = self.weight_input.text()
        price = self.price_input.text()
        postav = self.postav_input.currentText()

        if not name:
            QMessageBox.critical(self, 'Ошибка', 'Пожалуйста, введите название товара.')
            return
        if not weight:
            QMessageBox.critical(self, 'Ошибка', 'Пожалуйста, введите вес / объём.')
            return
        if not price:
            QMessageBox.critical(self, 'Ошибка', 'Пожалуйста, введите цену.')
            return

        # Добавление данных в таблицу 'product'
        self.cursor.execute("INSERT INTO product (Name, Weight, Price, Id_postav) VALUES (?, ?, ?, ?)",
                            (name, weight, price, postav))
        self.connection.commit()

        # Обновление таблицы
        self.fetch_data()
