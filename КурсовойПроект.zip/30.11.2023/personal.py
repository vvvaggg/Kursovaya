import sqlite3
from PyQt6.QtWidgets import QWidget, QDialog, QVBoxLayout, QPushButton,  QLineEdit,  QLabel, QMessageBox
from PyQt6.QtGui import QIcon
import re
from datetime import datetime


class StyledWidget(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet("""
            background-color: #f5f5f5;
            font-family: Arial, sans-serif;
        """)


class PersonalData(StyledWidget):
    def __init__(self):
        super().__init__()
        new_window = QDialog(self)
        new_window.setWindowTitle('Личный кабинет')
        new_window.setGeometry(370, 200, 350, 300)
        new_window.setWindowIcon(QIcon('icon2.png'))
        layout = QVBoxLayout()

        # Создание кнопки
        add_button = QPushButton('Добавить информацию о себе')
        add_button.clicked.connect(new_window.accept)
        add_button.setStyleSheet("""
                            background-color: #3498db;
                            color: white;
                            padding: 10px 15px;
                            border: none;
                            border-radius: 5px;
                            text-align: center;
                            text-decoration: none;
                            display: inline-block;
                            font-size: 14px;
                            margin: 4px 2px;
                            cursor: pointer;
                        """)

        login_label = QLabel('Логин:')
        self.login_input = QLineEdit()
        self.login_input.setPlaceholderText('Введите логин..')
        self.login_input.setStyleSheet("""
                padding: 8px;
                border: 2px solid #3498db;
                border-radius: 5px;
                background-color: #ecf0f1;
        """)
        layout.addWidget(login_label)
        layout.addWidget(self.login_input)

        password_label = QLabel('Пароль:')
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText('Введите пароль..')
        self.password_input.setStyleSheet("""
                        padding: 8px;
                        border: 2px solid #3498db;
                        border-radius: 5px;
                        background-color: #ecf0f1;
                """)
        self.password_input.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(password_label)
        layout.addWidget(self.password_input)

        label1 = QLabel('Дата рождения:')
        self.date_input = QLineEdit()
        self.date_input.setPlaceholderText('гггг.мм.дд')
        self.date_input.setStyleSheet("""
                                padding: 8px;
                                border: 2px solid #3498db;
                                border-radius: 5px;
                                background-color: #ecf0f1;
                        """)
        layout.addWidget(label1)
        layout.addWidget(self.date_input)

        self.date_input.editingFinished.connect(self.validate_date)

        label2 = QLabel('ФИО:')
        self.name_input = QLineEdit()
        layout.addWidget(label2)
        self.name_input.setPlaceholderText('Фамилия Имя Отчество')
        self.name_input.setStyleSheet("""
                                        padding: 8px;
                                        border: 2px solid #3498db;
                                        border-radius: 5px;
                                        background-color: #ecf0f1;
                                """)
        layout.addWidget(self.name_input)

        add_button.clicked.connect(self.validate_login_password)
        layout.addWidget(add_button)

        new_window.setLayout(layout)
        new_window.exec()

    def validate_date(self):
        date = self.date_input.text()
        regex = r'^\d{4}\.\d{2}\.\d{2}$'
        if not re.match(regex, date):
            self.date_input.setStyleSheet("""padding: 8px;
                                        border: 2px solid red;
                                        border-radius: 5px;
                                        background-color: #ecf0f1;
                                        """)
            QMessageBox.warning(self, 'Ошибка', 'Неправильный формат даты')
        else:
            try:
                datetime.strptime(date, '%Y.%m.%d')
                self.date_input.setStyleSheet("border: 1px solid black;")
            except ValueError:
                self.date_input.setStyleSheet("border: 1px solid red;")
                QMessageBox.warning(self, 'Ошибка', 'Несуществующая дата')

    def validate_login_password(self):
        login = self.login_input.text()
        password = self.password_input.text()

        # Проверка логина и пароля
        if self.check_login_password(login, password):
            birthday = self.date_input.text()
            fio = self.name_input.text()

            if not fio:
                QMessageBox.critical(self, 'Ошибка', 'Введите, пожалуйста, ФИО')
            else:
                # Сохранение данных в базу данных
                self.save_data_to_database(login, birthday, fio)
        else:
            QMessageBox.critical(self, 'Ошибка', 'Неправильный логин или пароль')

    def check_login_password(self, login, password):
        # Проверка логина и пароля в базе данных
        conn = sqlite3.connect('data.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE login = ? AND password = ?", (login, password))
        result = cursor.fetchone()
        conn.close()
        return result is not None

    def save_data_to_database(self, login, birthday, fio):
        conn = sqlite3.connect('data.db')
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE login = ?", (login,))
        result = cursor.fetchone()
        if result:
            cursor.execute("UPDATE users SET birthday = ?, FIO = ? WHERE login = ?", (birthday, fio, login))
            conn.commit()
            QMessageBox.information(self, 'Информация',
                                    f'Данные успешно обновлены:\n\nДата рождения: {birthday}\nФИО: {fio}')
        else:
            QMessageBox.critical(self, 'Ошибка', 'Пользователь не найден')
        conn.close()
